import 'package:flutter/material.dart';
void main(){
  runApp(App());
}
class App extends StatelessWidget{
  App({super.key})
@override
  Widget build(BuildContext context) {
   return MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold,
    appBar : AppBar(
      title: Text ("عنوان الصفحه"),

    ),
   )
  }
}